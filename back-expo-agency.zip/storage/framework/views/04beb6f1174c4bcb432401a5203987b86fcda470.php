

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <examen></examen>
            
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script>
        jQuery(document).ready(function($){
             var valor = $('#holis').val();
             
             $('#holis').click(function() {
             alert("Checkbox state (method 1) = " + $('#holis').prop('checked'));
             alert("Checkbox state (method 1) = " + $('#holis').is('checked'));
             console.log(valor)
             })
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\back-expo-agency\resources\views/preguntas/create-step-one.blade.php ENDPATH**/ ?>