Contenido el email
<a href="www.google.com">imprimir ficha</a><?php /**PATH C:\xampp\htdocs\back-expo-agency\resources\views/mails/email.blade.php ENDPATH**/ ?>