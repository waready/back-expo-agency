<table>
    <thead>
        <tr>
            <?php if($nombres == 1): ?>
            <th>Nombres</th>
            <?php endif; ?>
            <?php if($apellidos == 1): ?>
            <th>Apellidos</th>
            <?php endif; ?>
            <?php if($dni == 1): ?>
            <th>Dni</th>
            <?php endif; ?>
            <?php if($celular == 1): ?>
            <th>Celular</th>
            <?php endif; ?>
            <?php if($email == 1): ?>
            <th>Email</th>
            <?php endif; ?>
            <?php if($ugel == 1): ?>
            <th>Ugel</th>
            <?php endif; ?>
            <?php if($rol == 1): ?>
            <th>Rol</th>
            <?php endif; ?>
            <?php if($nivel == 1): ?>
            <th>Nivel</th>
            <?php endif; ?>
            <?php if($area == 1): ?>
            <th>Area</th>   
            <?php endif; ?> 
            <?php if($gestion == 1): ?>
            <th>Gestion</th>
            <?php endif; ?>
            <?php if($condicion == 1): ?>
            <th>Condicion</th>
            <?php endif; ?>
            <?php if($cargo == 1): ?>
            <th>Cargo</th>
            <?php endif; ?>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <?php if($nombres == 1): ?>
            <td><?php echo e($user->nombres); ?></td>
            <?php endif; ?>
            <?php if($apellidos == 1): ?>
            <td><?php echo e($user->apellidos); ?></td>
            <?php endif; ?>
            <?php if($dni == 1): ?>
            <td><?php echo e($user->dni); ?></td>
            <?php endif; ?>
            <?php if($celular == 1): ?>
            <td><?php echo e($user->celular); ?></td>
            <?php endif; ?>
            <?php if($email == 1): ?>
            <td><?php echo e($user->email); ?></td>
            <?php endif; ?>
            <?php if($ugel == 1): ?>
            <td><?php echo e($user->nombre); ?></td>
            <?php endif; ?>
            <?php if($rol == 1): ?>
            <td><?php echo e($user->participante); ?></td>
            <?php endif; ?>
            <?php if($nivel == 1): ?>
            <td><?php echo e($user->Nivel); ?></td>
            <?php endif; ?>
            <?php if($area == 1): ?>
            <td><?php echo e($user->Area); ?></td>
            <?php endif; ?> 
            <?php if($gestion == 1): ?>
            <td><?php echo e($user->Gestion); ?></td>
            <?php endif; ?>
            <?php if($condicion == 1): ?>
            <td><?php echo e($user->condicion); ?></td>
            <?php endif; ?>
            <?php if($cargo == 1): ?>
            <td><?php echo e($user->cargo); ?></td>
            <?php endif; ?>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH C:\xampp\htdocs\back-expo-agency\resources\views/reportes/report.blade.php ENDPATH**/ ?>