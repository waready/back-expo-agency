

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        
        <a href="javascript:imprSelec('imprimir')" class="btn btn-success" >Imprimir</a>
        <div class="col-md-12" id="imprimir">
            <div class="card-body">
                <?php if(session('status')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('status')); ?>

                    </div>
                <?php endif; ?>
                <div class="row">
                    <div class="col">
                        <h4>Monitoreado: <span class="strong"><?php echo e($evaluado['nombre']->nombres); ?> <?php echo e($evaluado['nombre']->apellidos); ?> </span> </h4> 
                    </div>
                    <div class="col">
                        <h4 class="float-right">Monitor: <span class="strong"><?php echo e($evaluado['monitor']->nombres); ?> <?php echo e($evaluado['monitor']->apellidos); ?> </span> </h4> 
                    </div>
                </div>
                 

                <div class="card">
                    <div class="card-header">
                       RESPUESTAS
                    </div>
                    <div class="card-body">
                        <table width="100%"
                            class="table table-striped table-bordered nowrap"
                            cellspacing="0"
                            id="students-table"
                        >
                            <thead>
                                <tr>
                                    <th><?php echo e(__("ID")); ?></th>
                                    
                                    <th><?php echo e(__("Enunciado Pregunta")); ?></th>
                                    <th><?php echo e(__("Respuesta")); ?></th>
                                    <th><?php echo e(__("Calificación")); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $respuestas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        
                                        <td>
                                        <?php echo e($item->numero); ?>

                                        </td>
                                        <td>
                                            <?php echo e($item->enunciado); ?>

                                        </td>
                                        <td>
                                            
                                            <?php if($item->respuesta == 1): ?>
                                                si
                                            <?php elseif($item->respuesta == 0): ?> 
                                                no
                                            <?php else: ?>
                                                error   
                                            <?php endif; ?>
                                        
                                        </td>
                                        <td>
                                            <?php echo e($item->calificacion); ?>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        
                    </div>
                </div>
                <div class="card-body">
                    <table width="100%"
                        class="table table-striped table-bordered nowrap"
                        cellspacing="0"
                        id="students-table"
                    >
                        <thead>
                            <tr>
                                <th><?php echo e(__("ID")); ?></th>
                                
                                <th><?php echo e(__("Categoria")); ?></th>
                                
                                <th><?php echo e(__("Porcentaje")); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    
                                    <td>
                                       <?php echo e($item->id); ?>

                                    </td>
                                    <td>
                                        <?php echo e($item->nombre); ?>

                                    </td>
                                    
                                    <td>
                                        <?php if($item->procentaje != null): ?>
                                            <?php echo e(($item->procentaje->num/$item->total->num)*100 . "%"); ?>    
                                        <?php else: ?>
                                            0%
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    
                </div>   
                
            </div>
            <div class="text-center">
                Resultado:
                <?php if($evaluado['porcentaje'] != null): ?>  
                    <?php if( (($evaluado['porcentaje']->num /30) *100) >= 0 &&  (($evaluado['porcentaje']->num /30) *100) <= 50): ?>
                        <h2>Inicio</h2>  
                    <?php elseif( (($evaluado['porcentaje']->num /30) *100) >= 51 &&  (($evaluado['porcentaje']->num /30) *100) <= 80): ?>
                        <h2>Proceso</h2>
                    <?php elseif( (($evaluado['porcentaje']->num /30) *100) >= 81 &&  (($evaluado['porcentaje']->num /30) *100) <= 100): ?>
                        <h2>Satisfactorio</h2>
                    <?php endif; ?>
                <?php else: ?>
                    0
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://jasonday.github.io/printThis/printThis.js"></script>
<script language="Javascript">
	function imprSelec(nombre) {
	  var ficha = document.getElementById(nombre);
	  var ventimp = window.open(' ', 'popimpr');
	  ventimp.document.write( ficha.innerHTML );
	  ventimp.document.close();
	  ventimp.print( );
	  ventimp.close();
	}
	</script>
  
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\back-expo-agency\resources\views/reportefinal.blade.php ENDPATH**/ ?>