<?php

/**
 * Author: Wilson Pilco Nuñez
 * Email: wilsonaux1@gmail.com
 * PHP Version: 7.4
 * Created at: 2021-07-31 17:30
 */

use Illuminate\Support\Facades\DB;
use App\User;
  // $examType,
  // $supervisorId,
  // $supervisedId
// $supervisor = User::find($examen->id_user_supervisor);
// $supervisado = User::find($examen->id_user_supervisado);

// $supervisores = DB::table('users')->get();
// $supervisados = DB::table('users')->get();
$supervisores = DB::table('users')->where('id',$supervisorId)->get();
$supervisados = DB::table('users')->where('id',$supervisedId)->get();
$tipoExamenes = DB::table('tipos')->get();
?>


<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row">
    <div class="col-md-5 mt-3">
      <h4>AJUSTE DEL MONITOREO</h4>

      <form method="POST" action="<?php echo e(url('/examenes/')); ?>">
        <?php echo e(csrf_field()); ?>

        <div class="mb-3">
          <label for="">Monitor:</label>
         
          <select class="custom-select"  name="id_user_supervisor">
            
            <?php $__currentLoopData = $supervisores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $miembro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($miembro->id); ?>" <?php echo e($miembro->id == $supervisorId ? 'selected' : ''); ?>>
              <?php echo e($miembro->nombres); ?> <?php echo e($miembro->apellidos); ?>

            </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>
        <div class="mb-3">
          <label for="">Monitoreado:</label>
          <select class="custom-select"  name="id_user_supervisado">
            
            <?php $__currentLoopData = $supervisados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $miembro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($miembro->id); ?>" <?php echo e($miembro->id == $supervisedId ? 'selected' : ''); ?>>
              <?php echo e($miembro->nombres); ?> <?php echo e($miembro->apellidos); ?>

            </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>
        <div class="mb-3">
          <label for="">Tipo Monitoreo:</label>
          <input type="hidden" value="<?php echo e($examType); ?>" name="id_tipo">
          <select class="custom-select" disabled name="id_tipo">
            <option value=""></option>
            <?php $__currentLoopData = $tipoExamenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($tipo->id); ?>" <?php echo e($tipo->id == $examType ? 'selected' : ''); ?>>
              <?php echo e($tipo->nombre); ?>

            </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>
        <button class="btn btn-primary" type="submit">Iniciar</button>
      </form>
    </div>
    <div class="col-md-5 offset-md-2 mt-3">
      
      <div class="mb-3">
        <div class="mb-3">
          Periodo de Monitoreo 
          <?php $__currentLoopData = $tipoExamenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($tipo->id == $examType): ?>
              <?php echo e($tipo->inicio); ?> -- <?php echo e($tipo->fin); ?>

            <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        
      </div>
      <?php if($examType == 1): ?>
      <div class="mb-3">
        <a href="/docs/F_Especialista_Ugel_v3.docx" type="button"  class="btn btn-success" value="">Descargar ficha vacia</a>
      </div>
      <?php endif; ?>
      <?php if($examType == 2): ?>
      <div class="mb-3">
        <a href="/docs/F_Director_v3.docx" type="button"  class="btn btn-success" value="">Descargar ficha vacia</a>
      </div>
      <?php endif; ?>
      
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\back-expo-agency\resources\views/examenes/pre-exam.blade.php ENDPATH**/ ?>