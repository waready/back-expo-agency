Contenido el email
<a href="www.google.com">imprimir ficha</a>