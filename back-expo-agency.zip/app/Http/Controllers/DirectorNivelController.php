<?php

namespace App\Http\Controllers;

use App\DirectorNivel;
use Illuminate\Http\Request;

class DirectorNivelController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\DirectorNivel  $directorNivel
     * @return \Illuminate\Http\Response
     */
    public function show(DirectorNivel $directorNivel)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\DirectorNivel  $directorNivel
     * @return \Illuminate\Http\Response
     */
    public function edit(DirectorNivel $directorNivel)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\DirectorNivel  $directorNivel
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, DirectorNivel $directorNivel)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\DirectorNivel  $directorNivel
     * @return \Illuminate\Http\Response
     */
    public function destroy(DirectorNivel $directorNivel)
    {
        //
    }
}
