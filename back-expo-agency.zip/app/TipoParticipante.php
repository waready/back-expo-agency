<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TipoParticipante extends Model
{
    const DIRECTOR = 4;
}
